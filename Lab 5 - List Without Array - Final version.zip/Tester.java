import java.util.Scanner;
import javax.lang.model.util.ElementScanner14;

public class Tester {
    public static void main(String[] args) {
        MyArrayList<String> arr = new MyArrayList<String>();
        System.out.println("A = {}");
        System.out.println("Acceptable commands: add value, addBefore index value, remove index, size, get index, set index value, find value, clear, extendLengthBy delta");
        System.out.println();
        while (true) {
            Scanner in = new Scanner(System.in);
            String input = in.next();
            //System.out.println(input);
            
            if (input.equals("add")) {
                String value = in.next();
                arr.add(value);
            }
            
            else if (input.equals("addBefore")) {
                int idx = in.nextInt();
                String value = in.next();
                if (0 <= idx  &&  idx < arr.size())
                    arr.addBefore(idx, value);
                else {
                    arr.addBefore(idx, value);
                    System.out.println();
                    continue;
                }
            }
            
            else if (input.equals("remove")) {
                int idx = in.nextInt();
                int tmp = arr.size();
                arr.remove(idx);
                if (tmp == arr.size()) {
                    System.out.println();
                    continue;
                }
            }
            
            else if (input.equals("size")) {
                System.out.println(arr.size());
                System.out.println();
                continue;
            }
            
            else if (input.equals("get")) {
                int idx = in.nextInt();
                if (0 <= idx  &&  idx < arr.size())
                    System.out.println(arr.get(idx));
                else
                    arr.get(idx);
                System.out.println();
                continue;
            }

            else if (input.equals("set")) {
                int idx = in.nextInt();
                String value = in.next();
                if (0 <= idx  &&  idx < arr.size())
                    arr.set(idx, value);
                else {
                    arr.set(idx, value);
                    System.out.println();
                    continue;
                }
            }
            
            else if (input.equals("find")) {
                String value = in.next();
                arr.indexOf(value).print();
                System.out.println();
                continue;
            }
            
            else if (input.equals("clear")) {
                arr.clear();
            }
            
            else if (input.equals("extendLengthBy")) {
                int delta = in.nextInt();
                MyArrayList<String> tmp = new MyArrayList<String>(arr.size() + delta);
                for (int i = 0; i < arr.size(); i++)
                    tmp.set(i, arr.get(i));
                arr = tmp;
            }
            
            else {
                System.out.println("Not a valid command.");
                System.out.println();
                continue;
            }
            
            System.out.print("A = ");
            arr.print();
            System.out.println();
        }
    }
}