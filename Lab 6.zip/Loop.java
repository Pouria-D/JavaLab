public class Loop extends Thread {
    public static int m = 0;
    static final int n = 50;

    public void run() {
        if (++m < n) {
            Loop thread = new Loop();
            thread.start();
            while (thread.isAlive());
        }
        System.out.println("Hello from thread " + m--);
    }

    public static void main(String[] args) {
        (new Loop()).start();
    }
}