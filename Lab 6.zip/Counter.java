public class Counter extends Thread {
    static int count = 0;

    static void inc() {//changing this line to static synchronized void inc(), eliminates the race conditions
        if (count <= 100) {
            try {
                Thread.sleep(10);
            }
            catch(InterruptedException e) {
                e.printStackTrace();
            }

            count++;
        }

        if (count > 100) {
            System.out.println("Failed");//It's possible to have this line executed; but it has very a low probability.
            //Only when for all pair of theareds, the first write instruction executes before the second read instruction.
        }
    }

    public void run() {
        inc();
    }

    public static void main(String args[]) {
        for (int i = 0; i < 101; i++)
            (new Counter()).start();
        
        /*try {
            Thread.sleep(2000);
        }
        catch(InterruptedException e) {
            e.printStackTrace();
        }*/

        //System.out.println(count);
    }
}