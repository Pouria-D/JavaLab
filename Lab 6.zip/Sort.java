import java.util.Random;

public class Sort extends Thread {
    public static int[] arr;
    public int l, r;

    public void merge(int[] res, int idx, int l1, int r1, int l2, int r2) {
        //System.out.println(idx + " " + l1 + " " + r1 + " " + l2 + " " + r2);
        if (l1 <= r1) {
            if (l2 <= r2) {
                if (arr[l1] >= arr[l2])
                    res[idx++] = arr[l1++];
                else
                    res[idx++] = arr[l2++];
                merge(res, idx, l1, r1, l2, r2);
                return;
            }
            res[idx++] = arr[l1++];
            merge(res, idx, l1, r1, l2, r2);
            return;
        }
        if (l2 <= r2) {
            res[idx++] = arr[l2++];
            merge(res, idx, l1, r1, l2, r2);
        }
    }

    public void run() {
        int Len = r - l + 1;
        if (Len == 1)
            return;
        int Len1 = Len / 2;
        Sort thread1 = new Sort();
        thread1.l = l;
        thread1.r = l + Len1 - 1;
        thread1.start();
        l += Len1;
        run();
        l -= Len1;
        while (thread1.isAlive());
        int[] res = new int[r - l + 1];
        merge(res, 0, l, l + Len1 - 1, l + Len1, r);
        for (int i = l; i <= r; i++)
            arr[i] = res[i - l];
        //System.out.print(l + " " + l + " " + (l + newLen - 1) + " " + (l + newLen) + " " + r);
    }

    public static void main(String[] args) {
        int N = 256;
        arr = new int[N];
        Random rand = new Random();
        int upperbound = 1000;
        for (int i = 0; i < N; i++)
            arr[i] = rand.nextInt(upperbound);

        for (int i = 0; i < N; i++)
            System.out.print(arr[i] + " ");
        System.out.println();

        Sort thread = new Sort();
        thread.l = 0;
        thread.r = N - 1;
        thread.start();
        while (thread.isAlive());

        for (int i = 0; i < N; i++)
            System.out.print(arr[i] + " ");
    }
}