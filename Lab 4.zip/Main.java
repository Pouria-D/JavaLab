import java.io.*;

public class Main
{
    public static void main(String[] args) throws FileNotFoundException
    {
        try
        {
            BufferedReader br = new BufferedReader(new FileReader("C:\\Users\\MohammadReza\\Desktop\\input.txt"));
            BufferedWriter bw = new BufferedWriter(new FileWriter("C:\\Users\\MohammadReza\\Desktop\\Path.txt"));
            String Str;
            boolean findIsCalled = false;
            Tree T = new Tree();
            String[] nodeNames = new String[0];
            while ((Str = br.readLine()) != null)
            {
                //System.out.println(Str);

                String[] splittedStr = Str.split("\\s+");

                //System.out.println(splittedStr.length);
                //for (int i = 0; i < splittedStr.length; i++) System.out.println(splittedStr[i]);
                if (splittedStr[0].equals("Find")) {
                    //System.out.println("Here");
                    if (splittedStr.length > 1)
                    {
                        bw.write("Input is of wrong format.");
                        bw.close();
                        return;
                    }
                    findIsCalled = true;
                    continue;
                }

                if (splittedStr.length != 2) {
                    bw.write("Input is of wrong format.");
                    bw.close();
                    return;
                }

                int idx1 = -1;
                for (int i = 0; i < nodeNames.length; i++)
                    if (nodeNames[i].equals(splittedStr[0]))
                    {
                        idx1 = i;
                        break;
                    }
                int idx2 = -1;
                for (int i = 0; i < nodeNames.length; i++)
                    if (nodeNames[i].equals(splittedStr[1]))
                    {
                        idx2 = i;
                        break;
                    }

                if (findIsCalled) {
                    if (idx1 == -1  ||  idx2 == -1)
                    {
                        bw.write("At least one of the nodes is not previously added to the tree.");
                        bw.close();
                        return;
                    }
        
                    if (idx1 == idx2)
                    {
                        bw.write(nodeNames[idx1]);
                        bw.close();
                        return;
                    }

                    Edge[] res = T.getPath(T.V[idx1], T.V[idx2]);
                    if (res == null)
                    {
                        bw.write("No Path");
                        bw.close();
                        return;
                    }
                    int[][] idxs = new int[res.length][2];
                    for (int i = 0; i < res.length; i++)
                        for (int j = 0; j < 2; j++)
                            for (int k = 0; k < T.V.length; k++)
                                if (T.V[k] == res[i].V[j])
                                {
                                    idxs[i][j] = k;
                                    break;
                                }
                    bw.write(nodeNames[idxs[res.length - 1][0]] + "\n");
                    for (int i = res.length - 1; i >= 0; i--)
                        bw.write(nodeNames[idxs[i][1]] + "\n");
                    bw.close();
                    return;
                }

                if (splittedStr[0].equals(splittedStr[1]))
                {
                    bw.write("Loops are not allowed in trees.");
                    bw.close();
                    return;
                }

                if (idx1 == -1)
                {
                    String[] tmp1 = new String[nodeNames.length + 1];
                    for (int i = 0; i < nodeNames.length; i++) tmp1[i] = nodeNames[i];
                    tmp1[nodeNames.length] = splittedStr[0];
                    nodeNames = tmp1;
                    T.addNode(new Node());
                    idx1 = nodeNames.length - 1;
                }
                if (idx2 == -1)
                {
                    String[] tmp2 = new String[nodeNames.length + 1];
                    for (int i = 0; i < nodeNames.length; i++) tmp2[i] = nodeNames[i];
                    tmp2[nodeNames.length] = splittedStr[1];
                    nodeNames = tmp2;
                    T.addNode(new Node());
                    idx2 = nodeNames.length - 1;
                }

                if (T.V[idx2].getInDegree() == 1)
                {
                    bw.write("The second node has another father.");
                    bw.close();
                    return;
                }
                T.addEdge(new DirectedEdge(T.V[idx1], T.V[idx2]));
            }
            //System.out.println("Here");
            bw.write("There was no query in the input file.");
            bw.close();
            return;
        }
        catch (Exception ex)
        {
            return;
        }
    }
}
