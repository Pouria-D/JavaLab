abstract class Edge
{
    Node[] V;
    boolean isDirected;
}