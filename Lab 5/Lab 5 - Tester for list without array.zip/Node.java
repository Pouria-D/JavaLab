class Node<E> {
    E value;
    Node<E> pre, next;

    Node() {
        value = null;
        pre = null;
        next = null;
    }
}